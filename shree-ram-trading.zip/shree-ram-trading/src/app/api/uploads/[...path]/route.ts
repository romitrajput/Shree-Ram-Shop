import { readFile } from "fs/promises";
import path from "path";
import { uploadDir } from "@/lib/storage";
import { getAdmin } from "@/lib/auth";

const TYPES: Record<string, string> = { ".jpg": "image/jpeg", ".png": "image/png", ".webp": "image/webp", ".avif": "image/avif" };

export async function GET(_req: Request, { params }: { params: Promise<{ path: string[] }> }) {
  const parts = (await params).path;
  // Payment screenshots are private to the owner.
  if (parts[0] === "payments" && !(await getAdmin())) return new Response("Not found", { status: 404 });

  const root = uploadDir();
  const full = path.resolve(root, ...parts);
  if (!full.startsWith(root + path.sep)) return new Response("Not found", { status: 404 });
  const type = TYPES[path.extname(full).toLowerCase()];
  if (!type) return new Response("Not found", { status: 404 });

  try {
    const data = await readFile(full);
    return new Response(new Uint8Array(data), {
      headers: {
        "content-type": type,
        "cache-control": parts[0] === "payments" ? "private, no-store" : "public, max-age=31536000, immutable"
      }
    });
  } catch {
    return new Response("Not found", { status: 404 });
  }
}
